"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import { GameState, Question, AnswerKey, PlayerAnswer } from "@/lib/gameTypes";
import { pusherClient } from "@/lib/pusher";
import { initAudio, playTick, playTimeUp } from "@/lib/sounds";

const TEAM_COLORS = ["#10b981","#34d399","#6ee7b7","#3b82f6","#f59e0b","#ec4899","#8b5cf6","#f87171","#06b6d4","#a3e635"];

async function broadcast(channel: string, event: string, data: any) {
  await fetch("/api/pusher", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ channel, event, data }) });
}

export default function HostPage() {
  const [roomCode, setRoomCode] = useState("");
  const [joined, setJoined] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [timeLimit, setTimeLimit] = useState(15);
  const [teams, setTeams] = useState<string[]>([]);
  const [phase, setPhase] = useState<GameState["phase"]>("waiting");
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [scores, setScores] = useState<{[k:string]:number}>({});
  const [roundScores, setRoundScores] = useState<{[k:string]:number}>({});
  const [timer, setTimer] = useState(0);
  const [answeredTeams, setAnsweredTeams] = useState<string[]>([]);
  const [pendingAnswers, setPendingAnswers] = useState<PlayerAnswer[]>([]);
  const timerRef = useRef<NodeJS.Timeout|null>(null);
  const [newQ, setNewQ] = useState<Question>({ text: "", choices: { A:"",B:"",C:"",D:"" }, correctAnswer:"A" });

  const broadcastState = useCallback(async (overrides: Partial<GameState> = {}) => {
    const state: GameState = {
      phase, currentQuestion: questions[currentQIndex] ? { text: questions[currentQIndex].text, choices: questions[currentQIndex].choices } : null,
      questionIndex: currentQIndex, totalQuestions: questions.length, timeLimit, timerValue: timer,
      scores, roundScores, teams, correctAnswer: null, answeredTeams, ...overrides,
    };
    await broadcast(`quiz-${roomCode}`, "game:state", state);
  }, [phase, questions, currentQIndex, timeLimit, timer, scores, roundScores, teams, roomCode, answeredTeams]);

  const startTimer = useCallback((seconds: number, onEnd: () => void) => {
    if (timerRef.current) clearInterval(timerRef.current);
    setTimer(seconds);
    let remaining = seconds;
    timerRef.current = setInterval(async () => {
      remaining -= 1; setTimer(remaining); playTick();
      await broadcast(`quiz-${roomCode}`, "game:timer", { value: remaining });
      if (remaining <= 0) { clearInterval(timerRef.current!); playTimeUp(); onEnd(); }
    }, 1000);
  }, [roomCode]);

  const goToReveal = useCallback(async (currentAnswers: PlayerAnswer[], currentScores: {[k:string]:number}) => {
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase("reveal");
    await broadcast(`quiz-${roomCode}`, "game:state", {
      phase: "reveal", currentQuestion: questions[currentQIndex] ? { text: questions[currentQIndex].text, choices: questions[currentQIndex].choices } : null,
      questionIndex: currentQIndex, totalQuestions: questions.length, timeLimit, timerValue: 0,
      scores: currentScores, roundScores: {}, teams, correctAnswer: null, answeredTeams: currentAnswers.map(a => a.teamName),
    });
    setTimeout(async () => {
      const correct = questions[currentQIndex].correctAnswer;
      const newRound: {[k:string]:number} = {};
      const newScores = { ...currentScores };
      teams.forEach(t => {
        const ans = currentAnswers.find(a => a.teamName === t);
        if (ans && ans.answer === correct) {
          const bonus = Math.floor((ans.timeRemaining / timeLimit) * 50);
          const pts = 100 + bonus;
          newRound[t] = pts; newScores[t] = (newScores[t]||0) + pts;
        } else { newRound[t] = 0; }
      });
      setRoundScores(newRound); setScores(newScores); setPhase("answer");
      const answerState: GameState = {
        phase: "answer", currentQuestion: { text: questions[currentQIndex].text, choices: questions[currentQIndex].choices },
        questionIndex: currentQIndex, totalQuestions: questions.length, timeLimit, timerValue: 0,
        scores: newScores, roundScores: newRound, teams, correctAnswer: correct, answeredTeams: currentAnswers.map(a => a.teamName),
      };
      await broadcast(`quiz-${roomCode}`, "game:state", answerState);
      setTimeout(async () => {
        setPhase("leaderboard");
        await broadcast(`quiz-${roomCode}`, "game:state", { ...answerState, phase: "leaderboard" });
      }, 5000);
    }, 4000);
  }, [questions, currentQIndex, teams, timeLimit, roomCode]);

  const startQuestion = useCallback(async (qIndex: number, currentScores: {[k:string]:number}) => {
    setPhase("question"); setAnsweredTeams([]); setPendingAnswers([]);
    const q = questions[qIndex];
    const state: GameState = {
      phase: "question", currentQuestion: { text: q.text, choices: q.choices },
      questionIndex: qIndex, totalQuestions: questions.length, timeLimit, timerValue: timeLimit,
      scores: currentScores, roundScores: {}, teams, correctAnswer: null, answeredTeams: [],
    };
    await broadcast(`quiz-${roomCode}`, "game:state", state);
    startTimer(timeLimit, () => {
      setPendingAnswers(prev => { goToReveal(prev, currentScores); return prev; });
    });
  }, [questions, timeLimit, teams, roomCode, startTimer, goToReveal]);

  const handleNextQuestion = useCallback(async () => {
    const nextIndex = currentQIndex + 1;
    if (nextIndex >= questions.length) {
      setPhase("game_over");
      await broadcast(`quiz-${roomCode}`, "game:state", {
        phase: "game_over", currentQuestion: null, questionIndex: nextIndex, totalQuestions: questions.length,
        timeLimit, timerValue: 0, scores, roundScores, teams, correctAnswer: null, answeredTeams: [],
      });
    } else { setCurrentQIndex(nextIndex); await startQuestion(nextIndex, scores); }
  }, [currentQIndex, questions.length, roomCode, scores, roundScores, teams, timeLimit, startQuestion]);

  useEffect(() => {
    if (!joined || !roomCode) return;
    initAudio();
    const ch = pusherClient.subscribe(`quiz-${roomCode}`);
    ch.bind("client-join", (data: { teamName: string }) => {
      setTeams(prev => {
        if (prev.includes(data.teamName)) return prev;
        const next = [...prev, data.teamName];
        setScores(s => ({ [data.teamName]: 0, ...s }));
        broadcast(`quiz-${roomCode}`, "game:state", {
          phase: "waiting", currentQuestion: null, questionIndex: 0, totalQuestions: questions.length,
          timeLimit, timerValue: 0, scores: { [data.teamName]: 0, ...scores }, roundScores: {}, teams: next, correctAnswer: null, answeredTeams: [],
        });
        return next;
      });
    });
    ch.bind("client-answer", (data: PlayerAnswer) => {
      setAnsweredTeams(prev => prev.includes(data.teamName) ? prev : [...prev, data.teamName]);
      setPendingAnswers(prev => prev.find(a => a.teamName === data.teamName) ? prev : [...prev, data]);
    });
    return () => { pusherClient.unsubscribe(`quiz-${roomCode}`); };
  }, [joined, roomCode]);

  const addQuestion = () => {
    if (!newQ.text || !newQ.choices.A || !newQ.choices.B || !newQ.choices.C || !newQ.choices.D) return;
    setQuestions(prev => [...prev, { ...newQ }]);
    setNewQ({ text: "", choices: { A:"",B:"",C:"",D:"" }, correctAnswer:"A" });
  };

  // ── Setup ──────────────────────────────────────────────
  if (!joined) {
    return (
      <main className="min-h-screen flex items-center justify-center p-5">
        <div className="card card-glow w-full max-w-sm p-7 anim-fade-up">
          <div className="flex items-center gap-3 mb-7">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(16,185,129,0.12)", border: "1px solid rgba(52,211,153,0.2)" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M12 15c3.314 0 6-2.686 6-6S15.314 3 12 3 6 5.686 6 9s2.686 6 6 6z" stroke="#10b981" strokeWidth="2"/>
                <path d="M3 21c0-3.314 4.03-6 9-6s9 2.686 9 6" stroke="#10b981" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <h1 style={{ fontWeight: 800, fontSize: "1.15rem", color: "#ecfdf5", letterSpacing: "-0.02em" }}>Host Setup</h1>
              <p style={{ fontSize: "0.78rem", color: "rgba(110,231,183,0.5)", fontWeight: 400 }}>Create your quiz room</p>
            </div>
          </div>
          <div>
            <label style={{ display: "block", fontSize: "0.78rem", fontWeight: 600, color: "rgba(110,231,183,0.6)", marginBottom: "7px", letterSpacing: "0.05em", textTransform: "uppercase" }}>Room Code</label>
            <input
              className="input-em input-mono"
              placeholder="E.G. QUIZ2025"
              value={roomCode}
              onChange={e => setRoomCode(e.target.value.toUpperCase())}
              onKeyDown={e => e.key === "Enter" && roomCode && setJoined(true)}
            />
            <p style={{ fontSize: "0.74rem", color: "rgba(110,231,183,0.35)", marginTop: "7px" }}>Share this code with your players</p>
          </div>
          <button className="btn-primary w-full mt-5" disabled={!roomCode} onClick={() => setJoined(true)} style={{ fontSize: "0.95rem" }}>
            Create Room →
          </button>
        </div>
      </main>
    );
  }

  // ── Game over ──────────────────────────────────────────
  if (phase === "game_over") {
    const sorted = [...teams].sort((a,b) => (scores[b]||0)-(scores[a]||0));
    return (
      <main className="min-h-screen flex flex-col items-center justify-center p-5 text-center gap-5">
        <div className="anim-bounce-in" style={{ fontSize: "3rem" }}>🏆</div>
        <div>
          <h1 style={{ fontWeight: 900, fontSize: "2rem", color: "#ecfdf5", letterSpacing: "-0.03em" }}>Game Over</h1>
          <p style={{ color: "#fcd34d", fontWeight: 700, fontSize: "1.1rem", marginTop: "6px" }}>🥇 {sorted[0]} wins!</p>
        </div>
        <div className="card anim-fade-up w-full max-w-md p-5">
          <div className="flex flex-col gap-2">
            {sorted.map((t, i) => (
              <div key={t} className="rank-row">
                <span style={{ fontWeight: 600, color: "#ecfdf5" }}>{i+1}. {t}</span>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, color: "#fcd34d" }}>{scores[t]||0} pts</span>
              </div>
            ))}
          </div>
        </div>
        <button className="btn-primary" onClick={() => window.location.href = "/"} style={{ padding: "13px 32px" }}>New Game</button>
      </main>
    );
  }

  // ── Main host view ─────────────────────────────────────
  return (
    <main className="min-h-screen p-4 pb-8">
      <div className="max-w-4xl mx-auto">
        {/* Top bar */}
        <div className="flex items-center justify-between mb-5 anim-fade-up">
          <div className="flex items-center gap-3">
            <span style={{ fontWeight: 800, fontSize: "1.05rem", color: "#ecfdf5" }}>QuizLive</span>
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "0.9rem", color: "#34d399", background: "rgba(52,211,153,0.1)", border: "1px solid rgba(52,211,153,0.2)", borderRadius: "8px", padding: "4px 10px", letterSpacing: "0.08em" }}>
              {roomCode}
            </div>
          </div>
          <span className="badge">{phase === "waiting" ? "Waiting" : phase === "question" ? "Live" : phase === "leaderboard" ? "Board" : phase.replace("_"," ")}</span>
        </div>

        {/* ── WAITING ───────────────────────────────────── */}
        {phase === "waiting" && (
          <div className="grid md:grid-cols-2 gap-4">
            {/* Question editor */}
            <div className="card p-5 anim-fade-up">
              <h2 style={{ fontWeight: 700, fontSize: "0.9rem", color: "rgba(110,231,183,0.6)", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "14px" }}>Add Question</h2>
              <textarea
                className="input-em"
                placeholder="Type your question here…"
                rows={3}
                style={{ resize: "none", marginBottom: "12px" }}
                value={newQ.text}
                onChange={e => setNewQ(q => ({ ...q, text: e.target.value }))}
              />
              <div className="flex flex-col gap-2 mb-3">
                {(["A","B","C","D"] as AnswerKey[]).map(k => (
                  <div key={k} className="flex items-center gap-2">
                    <button
                      onClick={() => setNewQ(q => ({ ...q, correctAnswer: k }))}
                      style={{
                        width: "28px", height: "28px", borderRadius: "50%", border: `2px solid ${newQ.correctAnswer === k ? "#10b981" : "rgba(52,211,153,0.2)"}`,
                        background: newQ.correctAnswer === k ? "rgba(16,185,129,0.25)" : "transparent",
                        cursor: "pointer", transition: "all 0.15s", flexShrink: 0,
                        fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "0.75rem",
                        color: newQ.correctAnswer === k ? "#34d399" : "rgba(110,231,183,0.4)",
                      }}
                    >{k}</button>
                    <input
                      className="input-em"
                      style={{ padding: "9px 13px", fontSize: "0.875rem" }}
                      placeholder={`Choice ${k}`}
                      value={newQ.choices[k]}
                      onChange={e => setNewQ(q => ({ ...q, choices: { ...q.choices, [k]: e.target.value } }))}
                    />
                  </div>
                ))}
              </div>
              <button className="btn-primary w-full" onClick={addQuestion}
                disabled={!newQ.text || !newQ.choices.A || !newQ.choices.B || !newQ.choices.C || !newQ.choices.D}
                style={{ fontSize: "0.875rem", padding: "11px" }}>
                + Add Question
              </button>

              {/* Timer */}
              <div style={{ marginTop: "16px" }}>
                <p style={{ fontSize: "0.75rem", fontWeight: 600, color: "rgba(110,231,183,0.5)", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "8px" }}>Timer per question</p>
                <div className="flex gap-2">
                  {[10,15,20,30].map(t => (
                    <button key={t} onClick={() => setTimeLimit(t)}
                      style={{
                        flex: 1, padding: "9px 0", borderRadius: "8px", border: "1px solid",
                        borderColor: timeLimit === t ? "#10b981" : "rgba(52,211,153,0.15)",
                        background: timeLimit === t ? "rgba(16,185,129,0.2)" : "transparent",
                        color: timeLimit === t ? "#34d399" : "rgba(110,231,183,0.5)",
                        fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "0.82rem", cursor: "pointer", transition: "all 0.15s",
                      }}>{t}s</button>
                  ))}
                </div>
              </div>
            </div>

            {/* Questions + Teams */}
            <div className="flex flex-col gap-4">
              {/* Questions list */}
              <div className="card p-5 anim-fade-up" style={{ animationDelay: "0.05s" }}>
                <div className="flex items-center justify-between mb-3">
                  <h2 style={{ fontWeight: 700, fontSize: "0.9rem", color: "rgba(110,231,183,0.6)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Questions</h2>
                  <span className="badge">{questions.length}</span>
                </div>
                {questions.length === 0 ? (
                  <p style={{ color: "rgba(110,231,183,0.3)", fontSize: "0.82rem", textAlign: "center", padding: "16px 0" }}>No questions yet</p>
                ) : (
                  <div className="flex flex-col gap-1.5" style={{ maxHeight: "200px", overflowY: "auto" }}>
                    {questions.map((q, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "8px", padding: "9px 12px", borderRadius: "8px", background: "rgba(10,31,23,0.6)", border: "1px solid transparent" }}>
                        <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.72rem", color: "rgba(110,231,183,0.4)", flexShrink: 0, paddingTop: "1px" }}>{String(i+1).padStart(2,"0")}</span>
                        <span style={{ fontSize: "0.82rem", color: "#ecfdf5", flex: 1, lineHeight: 1.4 }}>{q.text}</span>
                        <button className="btn-danger" style={{ padding: "3px 8px", fontSize: "0.72rem" }} onClick={() => setQuestions(p => p.filter((_,idx)=>idx!==i))}>✕</button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Teams */}
              <div className="card p-5 anim-fade-up" style={{ animationDelay: "0.1s" }}>
                <div className="flex items-center justify-between mb-3">
                  <h2 style={{ fontWeight: 700, fontSize: "0.9rem", color: "rgba(110,231,183,0.6)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Teams</h2>
                  <span className="badge">{teams.length}</span>
                </div>
                {teams.length === 0 ? (
                  <p style={{ color: "rgba(110,231,183,0.3)", fontSize: "0.82rem", textAlign: "center", padding: "16px 0" }}>Waiting for players to join…</p>
                ) : (
                  <div className="flex flex-col gap-1.5">
                    {teams.map((t, i) => (
                      <div key={t} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "9px 12px", borderRadius: "8px", background: "rgba(10,31,23,0.6)" }}>
                        <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: TEAM_COLORS[i % TEAM_COLORS.length], flexShrink: 0 }} />
                        <span style={{ fontSize: "0.875rem", fontWeight: 600, color: "#ecfdf5" }}>{t}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <button
                className="btn-primary anim-fade-up"
                style={{ padding: "16px", fontSize: "1rem", animationDelay: "0.15s" }}
                disabled={questions.length === 0 || teams.length === 0}
                onClick={() => startQuestion(0, Object.fromEntries(teams.map(t => [t, 0])))}
              >
                Start Game →
              </button>
            </div>
          </div>
        )}

        {/* ── QUESTION ──────────────────────────────────── */}
        {phase === "question" && (
          <div className="card p-6 anim-fade-up text-center">
            <div className="flex items-center justify-between mb-5">
              <span className="badge">Q{currentQIndex+1} / {questions.length}</span>
              <div className={timer <= 5 ? "timer-warn" : ""} style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 900, fontSize: "3.5rem", color: timer <= 5 ? "#f87171" : "#34d399", lineHeight: 1 }}>
                {timer}
              </div>
              <span className="badge">{answeredTeams.length}/{teams.length} ans</span>
            </div>
            <div className="timer-bar mb-6">
              <div className="timer-bar-fill" style={{ width: `${(timer/timeLimit)*100}%`, background: timer <= 5 ? "#f87171" : "#10b981" }} />
            </div>
            <p style={{ fontWeight: 700, fontSize: "clamp(1rem, 3vw, 1.4rem)", color: "#ecfdf5", marginBottom: "20px", lineHeight: 1.4 }}>
              {questions[currentQIndex]?.text}
            </p>
            <div className="grid grid-cols-2 gap-2 mb-5 text-left">
              {(["A","B","C","D"] as AnswerKey[]).map(k => (
                <div key={k} style={{ padding: "12px 14px", borderRadius: "10px", background: "rgba(10,31,23,0.7)", border: "1px solid rgba(52,211,153,0.1)", display: "flex", gap: "10px", alignItems: "flex-start" }}>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", fontWeight: 700, color: "rgba(110,231,183,0.4)", flexShrink: 0 }}>{k}</span>
                  <span style={{ fontSize: "0.85rem", color: "#ecfdf5" }}>{questions[currentQIndex]?.choices[k]}</span>
                </div>
              ))}
            </div>
            {teams.length > 0 && (
              <div className="flex flex-wrap gap-2 justify-center mb-5">
                {teams.map(t => (
                  <span key={t} style={{ padding: "5px 12px", borderRadius: "100px", fontSize: "0.75rem", fontWeight: 600, background: answeredTeams.includes(t) ? "rgba(16,185,129,0.2)" : "rgba(10,31,23,0.7)", border: `1px solid ${answeredTeams.includes(t) ? "rgba(52,211,153,0.3)" : "rgba(52,211,153,0.1)"}`, color: answeredTeams.includes(t) ? "#6ee7b7" : "rgba(236,253,245,0.4)" }}>
                    {answeredTeams.includes(t) ? "✓ " : ""}{t}
                  </span>
                ))}
              </div>
            )}
            <div className="flex gap-2 justify-center">
              <button className="btn-ghost" onClick={() => { if(timerRef.current) clearInterval(timerRef.current); setPendingAnswers(p => { goToReveal(p, scores); return p; }); }}>
                Skip to Reveal
              </button>
              <button className="btn-danger" style={{ padding: "10px 18px", fontSize: "0.875rem" }}
                onClick={() => { setPhase("game_over"); broadcast(`quiz-${roomCode}`, "game:state", { phase: "game_over", currentQuestion: null, questionIndex: currentQIndex, totalQuestions: questions.length, timeLimit, timerValue: 0, scores, roundScores, teams, correctAnswer: null, answeredTeams }); }}>
                End Game
              </button>
            </div>
          </div>
        )}

        {/* ── REVEAL ────────────────────────────────────── */}
        {(phase === "reveal" || phase === "answer") && (
          <div className="card p-8 anim-fade-up text-center">
            {phase === "reveal" ? (
              <div>
                <div className="dot-loader justify-center mb-4"><span/><span/><span/></div>
                <p style={{ fontWeight: 700, fontSize: "1.1rem", color: "#ecfdf5" }}>Revealing answer…</p>
              </div>
            ) : (
              <div>
                <p style={{ fontSize: "0.75rem", fontWeight: 600, color: "rgba(110,231,183,0.5)", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "8px" }}>Correct Answer</p>
                <div className="anim-scale-in" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 900, fontSize: "3.5rem", color: "#34d399", marginBottom: "4px" }}>
                  {questions[currentQIndex]?.correctAnswer}
                </div>
                <p style={{ fontWeight: 700, color: "#ecfdf5", fontSize: "1.1rem", marginBottom: "20px" }}>
                  {questions[currentQIndex]?.choices[questions[currentQIndex]?.correctAnswer]}
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {teams.map(t => (
                    <div key={t} className="rank-row" style={{ padding: "10px 14px" }}>
                      <span style={{ fontSize: "0.875rem", fontWeight: 600 }}>{t}</span>
                      <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, color: (roundScores[t]||0) > 0 ? "#34d399" : "rgba(110,231,183,0.3)", fontSize: "0.9rem" }}>+{roundScores[t]||0}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── LEADERBOARD ───────────────────────────────── */}
        {phase === "leaderboard" && (
          <div className="card p-6 anim-fade-up">
            <h2 style={{ fontWeight: 800, fontSize: "1.2rem", textAlign: "center", marginBottom: "16px", color: "#ecfdf5", letterSpacing: "-0.02em" }}>Leaderboard</h2>
            <div className="flex flex-col gap-2 mb-5">
              {[...teams].sort((a,b) => (scores[b]||0)-(scores[a]||0)).map((t, i) => (
                <div key={t} className={`stagger-item rank-row`}>
                  <div className="flex items-center gap-3">
                    <span style={{ fontSize: i < 3 ? "1.1rem" : "0.85rem", minWidth: "1.5rem", textAlign: "center" }}>
                      {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `${i+1}.`}
                    </span>
                    <span style={{ fontWeight: 600, color: "#ecfdf5", fontSize: "0.9rem" }}>{t}</span>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, color: "#ecfdf5", fontSize: "0.95rem" }}>{scores[t]||0}</div>
                    {(roundScores[t]||0) > 0 && <div style={{ fontSize: "0.7rem", color: "#34d399", fontWeight: 600 }}>+{roundScores[t]}</div>}
                  </div>
                </div>
              ))}
            </div>
            <button className="btn-primary w-full" onClick={handleNextQuestion} style={{ padding: "14px", fontSize: "0.95rem" }}>
              {currentQIndex + 1 >= questions.length ? "End Game →" : "Next Question →"}
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
