"use client";
import { useState, useEffect, useRef } from "react";
import { GameState, AnswerKey } from "@/lib/gameTypes";
import { pusherClient } from "@/lib/pusher";
import { initAudio, playCorrect, playWrong, playSuspense, playCelebration, playLeaderboard } from "@/lib/sounds";

const ANS_CLASSES: Record<AnswerKey, string> = {
  A: "ans-a", B: "ans-b", C: "ans-c", D: "ans-d",
};
const ANS_LABELS: Record<AnswerKey, string> = {
  A: "A", B: "B", C: "C", D: "D",
};

function RoomCodeInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <input
      className="input-em input-mono"
      placeholder="ROOM CODE"
      value={value}
      onChange={e => onChange(e.target.value.toUpperCase())}
      maxLength={12}
      autoComplete="off"
      spellCheck={false}
    />
  );
}

export default function PlayPage() {
  const [roomCode, setRoomCode] = useState("");
  const [teamName, setTeamName] = useState("");
  const [joined, setJoined] = useState(false);
  const [error, setError] = useState("");
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [myAnswer, setMyAnswer] = useState<AnswerKey | null>(null);
  const [myPoints, setMyPoints] = useState(0);
  const [countdown, setCountdown] = useState(3);
  const [showCountdown, setShowCountdown] = useState(false);
  const channelRef = useRef<any>(null);
  const audioInitRef = useRef(false);
  const prevPhaseRef = useRef<string>("");
  const countKeyRef = useRef(0);

  const initAudioOnce = () => {
    if (!audioInitRef.current) { initAudio(); audioInitRef.current = true; }
  };

  const spawnConfetti = () => {
    const colors = ["#10b981","#34d399","#6ee7b7","#a7f3d0","#fcd34d","#93c5fd","#fca5a5"];
    for (let i = 0; i < 80; i++) {
      const el = document.createElement("div");
      el.className = "confetti-piece";
      el.style.left = Math.random() * 100 + "vw";
      el.style.top = "-10px";
      el.style.background = colors[Math.floor(Math.random() * colors.length)];
      el.style.borderRadius = Math.random() > 0.5 ? "50%" : "2px";
      el.style.width = (6 + Math.random() * 6) + "px";
      el.style.height = (6 + Math.random() * 6) + "px";
      el.style.animationDuration = (2.5 + Math.random() * 2.5) + "s";
      el.style.animationDelay = (Math.random() * 1.5) + "s";
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 6000);
    }
  };

  const joinGame = async () => {
    initAudioOnce();
    if (!roomCode || !teamName) return;
    setError("");
    const ch = pusherClient.subscribe(`quiz-${roomCode}`);
    channelRef.current = ch;
    ch.bind("pusher:subscription_error", () => setError("Cannot connect. Check the room code."));
    ch.bind("game:state", (state: GameState) => {
      const prev = prevPhaseRef.current;
      const cur = state.phase;
      if (cur === "answer" && prev !== "answer") {
        setMyAnswer(ans => {
          if (ans && state.correctAnswer && ans === state.correctAnswer) {
            setMyPoints(state.roundScores[teamName] || 0);
            playCorrect();
          } else { setMyPoints(0); playWrong(); }
          return ans;
        });
      }
      if (cur === "reveal" && prev !== "reveal") playSuspense();
      if (cur === "leaderboard" && prev !== "leaderboard") {
        const sorted = [...state.teams].sort((a,b) => (state.scores[b]||0)-(state.scores[a]||0));
        sorted[0] === teamName ? playCelebration() : playLeaderboard();
      }
      if (cur === "game_over" && prev !== "game_over") {
        const sorted = [...state.teams].sort((a,b) => (state.scores[b]||0)-(state.scores[a]||0));
        if (sorted[0] === teamName) spawnConfetti();
      }
      if (cur === "question" && prev === "leaderboard") {
        setMyAnswer(null);
        setShowCountdown(true);
        countKeyRef.current++;
        setCountdown(3);
        let c = 3;
        const iv = setInterval(() => {
          c -= 1; setCountdown(c);
          if (c <= 0) { clearInterval(iv); setShowCountdown(false); }
        }, 1000);
      }
      if (cur === "question" && prev !== "question" && prev !== "leaderboard") setMyAnswer(null);
      prevPhaseRef.current = cur;
      setGameState(state);
    });
    ch.bind("game:timer", (data: { value: number }) => {
      setGameState(prev => prev ? { ...prev, timerValue: data.value } : prev);
    });
    setJoined(true);
    ch.bind("pusher:subscription_succeeded", () => ch.trigger("client-join", { teamName }));
    setTimeout(() => ch.trigger("client-join", { teamName }), 500);
  };

  const submitAnswer = (answer: AnswerKey) => {
    if (myAnswer) return;
    initAudioOnce();
    setMyAnswer(answer);
    channelRef.current?.trigger("client-answer", { teamName, answer, timeRemaining: gameState?.timerValue || 0 });
  };

  // ── Join screen ────────────────────────────────────────
  if (!joined) {
    return (
      <main className="min-h-screen flex items-center justify-center p-5">
        <div className="card card-glow w-full max-w-sm p-7 anim-fade-up">
          {/* Header */}
          <div className="flex items-center gap-3 mb-7">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(16,185,129,0.12)", border: "1px solid rgba(52,211,153,0.2)" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="9" stroke="#10b981" strokeWidth="2"/>
                <path d="M10 8l6 4-6 4V8z" fill="#10b981"/>
              </svg>
            </div>
            <div>
              <h1 style={{ fontWeight: 800, fontSize: "1.15rem", color: "#ecfdf5", letterSpacing: "-0.02em" }}>Join a Game</h1>
              <p style={{ fontSize: "0.78rem", color: "rgba(110,231,183,0.5)", fontWeight: 400 }}>Enter your details to compete</p>
            </div>
          </div>

          {error && (
            <div className="anim-scale-in mb-4 p-3 rounded-lg" style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)" }}>
              <p style={{ fontSize: "0.82rem", color: "#fca5a5", fontWeight: 500 }}>{error}</p>
            </div>
          )}

          <div className="flex flex-col gap-4">
            <div>
              <label style={{ display: "block", fontSize: "0.78rem", fontWeight: 600, color: "rgba(110,231,183,0.6)", marginBottom: "7px", letterSpacing: "0.05em", textTransform: "uppercase" }}>Room Code</label>
              <RoomCodeInput value={roomCode} onChange={setRoomCode} />
            </div>
            <div>
              <label style={{ display: "block", fontSize: "0.78rem", fontWeight: 600, color: "rgba(110,231,183,0.6)", marginBottom: "7px", letterSpacing: "0.05em", textTransform: "uppercase" }}>Team Name</label>
              <input
                className="input-em"
                placeholder="e.g. Team Alpha"
                value={teamName}
                onChange={e => setTeamName(e.target.value)}
                onKeyDown={e => e.key === "Enter" && joinGame()}
              />
            </div>
            <button
              className="btn-primary w-full mt-1"
              disabled={!roomCode || !teamName}
              onClick={joinGame}
              style={{ fontSize: "0.95rem", padding: "14px" }}
            >
              Join Game →
            </button>
          </div>
        </div>
      </main>
    );
  }

  // ── Waiting ────────────────────────────────────────────
  if (!gameState || gameState.phase === "waiting") {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center p-5 text-center">
        <div className="anim-fade-up">
          <div className="pulse-glow inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-6"
            style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(52,211,153,0.2)" }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="9" stroke="#10b981" strokeWidth="1.5"/>
              <path d="M12 7v5l3 3" stroke="#34d399" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>
          <h2 style={{ fontWeight: 800, fontSize: "1.3rem", color: "#ecfdf5", marginBottom: "6px" }}>Waiting for host</h2>
          <p style={{ color: "rgba(110,231,183,0.5)", fontSize: "0.87rem", marginBottom: "4px" }}>Room</p>
          <p style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "1.2rem", color: "#34d399", marginBottom: "24px", letterSpacing: "0.1em" }}>{roomCode}</p>

          {(gameState?.teams || []).length > 0 && (
            <div className="card w-full max-w-xs p-5" style={{ textAlign: "left" }}>
              <p style={{ fontSize: "0.75rem", fontWeight: 600, color: "rgba(110,231,183,0.5)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "10px" }}>
                Players ({(gameState?.teams || []).length})
              </p>
              <div className="flex flex-col gap-2">
                {(gameState?.teams || []).map((t) => (
                  <div key={t} className="flex items-center gap-2" style={{ padding: "8px 12px", borderRadius: "8px", background: t === teamName ? "rgba(16,185,129,0.12)" : "rgba(10,31,23,0.5)", border: `1px solid ${t === teamName ? "rgba(52,211,153,0.2)" : "transparent"}` }}>
                    <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: t === teamName ? "#10b981" : "rgba(52,211,153,0.3)", flexShrink: 0 }} />
                    <span style={{ fontSize: "0.875rem", fontWeight: t === teamName ? 700 : 400, color: t === teamName ? "#6ee7b7" : "rgba(236,253,245,0.7)" }}>{t}</span>
                    {t === teamName && <span style={{ marginLeft: "auto", fontSize: "0.7rem", color: "rgba(110,231,183,0.5)", fontWeight: 500 }}>you</span>}
                  </div>
                ))}
              </div>
            </div>
          )}
          <div className="dot-loader mt-6"><span/><span/><span/></div>
        </div>
      </main>
    );
  }

  // ── Countdown ──────────────────────────────────────────
  if (showCountdown) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center text-center">
        <p style={{ fontSize: "0.8rem", fontWeight: 600, letterSpacing: "0.12em", color: "rgba(110,231,183,0.5)", textTransform: "uppercase", marginBottom: "16px" }}>Get Ready</p>
        <div key={countKeyRef.current + "-" + countdown} className="anim-count"
          style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 900, fontSize: "clamp(6rem, 25vw, 10rem)", color: "#10b981", lineHeight: 1, letterSpacing: "-0.05em" }}>
          {countdown > 0 ? countdown : "Go!"}
        </div>
      </main>
    );
  }

  // ── Question ───────────────────────────────────────────
  if (gameState.phase === "question") {
    const pct = Math.max(0, (gameState.timerValue / gameState.timeLimit) * 100);
    const isUrgent = gameState.timerValue <= 5;
    return (
      <main className="min-h-screen flex flex-col p-4 pb-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <span className="badge">Q{gameState.questionIndex+1} / {gameState.totalQuestions}</span>
          <div className={`${isUrgent ? "timer-warn" : ""}`} style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "1.6rem", color: isUrgent ? "#f87171" : "#34d399", lineHeight: 1, minWidth: "2ch", textAlign: "center" }}>
            {gameState.timerValue}
          </div>
          <span className="badge">{teamName}</span>
        </div>

        {/* Timer bar */}
        <div className="timer-bar mb-4">
          <div className="timer-bar-fill" style={{ width: `${pct}%`, background: isUrgent ? "#f87171" : "#10b981" }} />
        </div>

        {/* Question */}
        <div className="card flex-1 flex items-center justify-center p-6 mb-4" style={{ minHeight: "120px" }}>
          <p style={{ fontWeight: 700, fontSize: "clamp(1rem, 3.5vw, 1.3rem)", color: "#ecfdf5", textAlign: "center", lineHeight: 1.4 }}>
            {gameState.currentQuestion?.text}
          </p>
        </div>

        {/* Choices */}
        {myAnswer ? (
          <div className="anim-scale-in card p-6 text-center" style={{ borderColor: "rgba(52,211,153,0.3)" }}>
            <div style={{ fontSize: "1.5rem", marginBottom: "6px" }}>⏳</div>
            <p style={{ fontWeight: 700, color: "#ecfdf5", fontSize: "0.95rem" }}>Answer locked in</p>
            <p style={{ color: "rgba(110,231,183,0.5)", fontSize: "0.8rem", marginTop: "4px" }}>Waiting for results…</p>
          </div>
        ) : gameState.timerValue === 0 ? (
          <div className="card p-6 text-center" style={{ borderColor: "rgba(239,68,68,0.25)" }}>
            <p style={{ fontWeight: 700, color: "#f87171" }}>Time&apos;s up!</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {(["A","B","C","D"] as AnswerKey[]).map(k => (
              <button key={k} onClick={() => submitAnswer(k)}
                className={`answer-btn ${ANS_CLASSES[k]}`}
                disabled={!!myAnswer}>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "0.8rem", flexShrink: 0, opacity: 0.7 }}>{k}</span>
                <span style={{ lineHeight: 1.3 }}>{gameState.currentQuestion?.choices[k]}</span>
              </button>
            ))}
          </div>
        )}
      </main>
    );
  }

  // ── Reveal ─────────────────────────────────────────────
  if (gameState.phase === "reveal") {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center p-5 text-center">
        <div className="anim-scale-in">
          <div className="dot-loader mb-6"><span/><span/><span/></div>
          <p style={{ fontWeight: 700, fontSize: "1.1rem", color: "#ecfdf5" }}>Revealing answer</p>
          <p style={{ color: "rgba(110,231,183,0.45)", fontSize: "0.82rem", marginTop: "6px" }}>Just a moment…</p>
        </div>
      </main>
    );
  }

  // ── Answer reveal ──────────────────────────────────────
  if (gameState.phase === "answer") {
    const isCorrect = myAnswer !== null && myAnswer === gameState.correctAnswer;
    const correct = gameState.correctAnswer;
    return (
      <main className="min-h-screen flex flex-col items-center justify-center p-5 text-center gap-5">
        <div className="anim-bounce-in" style={{ fontSize: "3.5rem", lineHeight: 1 }}>
          {isCorrect ? "✅" : "❌"}
        </div>
        <div>
          <h2 style={{ fontWeight: 800, fontSize: "1.5rem", color: isCorrect ? "#34d399" : "#f87171", letterSpacing: "-0.02em" }}>
            {isCorrect ? "Correct!" : myAnswer ? "Wrong answer" : "No answer"}
          </h2>
          {isCorrect && (
            <p className="anim-fade-in" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "1.4rem", color: "#fcd34d", marginTop: "4px" }}>
              +{myPoints} pts
            </p>
          )}
        </div>

        <div className="card anim-fade-up w-full max-w-sm p-5">
          <p style={{ fontSize: "0.75rem", fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "rgba(110,231,183,0.5)", marginBottom: "8px" }}>Correct Answer</p>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "2rem", color: "#34d399", marginBottom: "4px" }}>{correct}</div>
          <p style={{ fontWeight: 600, color: "#ecfdf5", fontSize: "0.95rem" }}>{correct && gameState.currentQuestion?.choices[correct]}</p>
        </div>

        {myAnswer && !isCorrect && correct && (
          <p className="anim-fade-in" style={{ fontSize: "0.82rem", color: "rgba(236,253,245,0.45)" }}>
            You answered: <span style={{ fontWeight: 700, color: "#fca5a5" }}>{myAnswer} — {gameState.currentQuestion?.choices[myAnswer]}</span>
          </p>
        )}
      </main>
    );
  }

  // ── Leaderboard ────────────────────────────────────────
  if (gameState.phase === "leaderboard") {
    const sorted = [...gameState.teams].sort((a,b) => (gameState.scores[b]||0)-(gameState.scores[a]||0));
    const myRank = sorted.indexOf(teamName) + 1;
    const medals = ["🥇","🥈","🥉"];
    return (
      <main className="min-h-screen p-4 pb-8">
        <div className="max-w-sm mx-auto">
          <h2 className="anim-fade-up" style={{ fontWeight: 800, fontSize: "1.3rem", textAlign: "center", marginBottom: "16px", color: "#ecfdf5", letterSpacing: "-0.02em" }}>
            Leaderboard
          </h2>

          {/* My rank pill */}
          <div className="anim-scale-in card card-glow mb-4 p-4 flex items-center justify-between" style={{ borderColor: "rgba(52,211,153,0.25)" }}>
            <div>
              <p style={{ fontSize: "0.72rem", fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "rgba(110,231,183,0.5)", marginBottom: "2px" }}>Your rank</p>
              <p style={{ fontWeight: 800, fontSize: "1.6rem", color: "#34d399", lineHeight: 1, letterSpacing: "-0.03em" }}>#{myRank}</p>
            </div>
            <div style={{ textAlign: "right" }}>
              <p style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "1.2rem", color: "#ecfdf5" }}>{gameState.scores[teamName]||0}</p>
              <p style={{ fontSize: "0.75rem", color: "rgba(110,231,183,0.5)" }}>total pts</p>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            {sorted.map((t, i) => (
              <div key={t} className={`stagger-item rank-row ${t === teamName ? "rank-row-me" : ""}`}>
                <div className="flex items-center gap-3">
                  <span style={{ fontSize: i < 3 ? "1.1rem" : "0.85rem", fontWeight: i < 3 ? 700 : 500, color: i < 3 ? "#fcd34d" : "rgba(110,231,183,0.4)", minWidth: "1.5rem", textAlign: "center" }}>
                    {i < 3 ? medals[i] : `${i+1}.`}
                  </span>
                  <span style={{ fontWeight: 600, fontSize: "0.9rem", color: t === teamName ? "#6ee7b7" : "#ecfdf5" }}>{t}</span>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: "0.95rem", color: "#ecfdf5" }}>{gameState.scores[t]||0}</div>
                  {gameState.roundScores[t] > 0 && (
                    <div style={{ fontSize: "0.72rem", color: "#34d399", fontWeight: 600 }}>+{gameState.roundScores[t]}</div>
                  )}
                </div>
              </div>
            ))}
          </div>

          <p className="anim-fade-in" style={{ textAlign: "center", color: "rgba(110,231,183,0.35)", fontSize: "0.78rem", marginTop: "20px", animationDelay: "0.5s" }}>
            Next question incoming…
          </p>
        </div>
      </main>
    );
  }

  // ── Game over ──────────────────────────────────────────
  if (gameState.phase === "game_over") {
    const sorted = [...gameState.teams].sort((a,b) => (gameState.scores[b]||0)-(gameState.scores[a]||0));
    const isWinner = sorted[0] === teamName;
    return (
      <main className="min-h-screen flex flex-col items-center justify-center p-5 text-center gap-5">
        <div className="anim-bounce-in" style={{ fontSize: "3rem" }}>{isWinner ? "🏆" : "🎯"}</div>
        <div>
          <h1 style={{ fontWeight: 900, fontSize: "clamp(1.5rem, 6vw, 2rem)", color: isWinner ? "#34d399" : "#ecfdf5", letterSpacing: "-0.03em" }}>
            {isWinner ? "You Win!" : "Game Over"}
          </h1>
          <p style={{ color: "rgba(110,231,183,0.55)", fontSize: "0.875rem", marginTop: "4px" }}>
            🏆 <span style={{ color: "#fcd34d", fontWeight: 700 }}>{sorted[0]}</span> wins the game
          </p>
        </div>

        <div className="card anim-fade-up w-full max-w-sm p-5">
          <div className="flex flex-col gap-2">
            {sorted.map((t, i) => (
              <div key={t} className={`rank-row ${t === teamName ? "rank-row-me" : ""}`}>
                <div className="flex items-center gap-3">
                  <span style={{ fontSize: "0.85rem", color: "rgba(110,231,183,0.4)", minWidth: "1.5rem" }}>{i+1}.</span>
                  <span style={{ fontWeight: 600, fontSize: "0.9rem" }}>{t}</span>
                </div>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, color: "#fcd34d" }}>{gameState.scores[t]||0}</span>
              </div>
            ))}
          </div>
        </div>

        <button className="btn-primary" onClick={() => window.location.href = "/"} style={{ padding: "13px 32px" }}>
          Back to Home
        </button>
      </main>
    );
  }

  return null;
}
