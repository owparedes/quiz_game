import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-6">
      {/* Logo mark */}
      <div className="anim-fade-up mb-10 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-5"
          style={{ background: "rgba(16,185,129,0.12)", border: "1px solid rgba(52,211,153,0.25)" }}>
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
            <path d="M8 20L16 8L24 20" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M11 16h10" stroke="#34d399" strokeWidth="2" strokeLinecap="round"/>
            <circle cx="16" cy="24" r="2" fill="#34d399"/>
          </svg>
        </div>
        <h1 style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, fontSize: "clamp(2rem, 6vw, 3rem)", letterSpacing: "-0.03em", lineHeight: 1, color: "#ecfdf5", marginBottom: "10px" }}>
          Quiz<span style={{ color: "#10b981" }}>Live</span>
        </h1>
        <p style={{ color: "rgba(110,231,183,0.6)", fontWeight: 400, fontSize: "1rem", letterSpacing: "0.01em" }}>
          Real-time multiplayer quiz battles
        </p>
      </div>

      {/* Cards */}
      <div className="anim-fade-up w-full max-w-sm flex flex-col gap-3" style={{ animationDelay: "0.1s" }}>
        <Link href="/host" className="card card-glow group block p-6 no-underline"
          style={{ textDecoration: "none" }}>
          <div className="flex items-center gap-4">
            <div className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(16,185,129,0.12)", border: "1px solid rgba(52,211,153,0.2)", transition: "all 0.2s" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path d="M12 15c3.314 0 6-2.686 6-6S15.314 3 12 3 6 5.686 6 9s2.686 6 6 6z" stroke="#10b981" strokeWidth="2"/>
                <path d="M3 21c0-3.314 4.03-6 9-6s9 2.686 9 6" stroke="#10b981" strokeWidth="2" strokeLinecap="round"/>
                <circle cx="19" cy="9" r="2" fill="#34d399"/>
                <path d="M19 7v4M17 9h4" stroke="#022c22" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <div style={{ fontWeight: 700, fontSize: "1rem", color: "#ecfdf5", marginBottom: "2px" }}>Host a Game</div>
              <div style={{ fontSize: "0.82rem", color: "rgba(110,231,183,0.55)", fontWeight: 400 }}>Create room, add questions, manage game</div>
            </div>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, color: "rgba(52,211,153,0.4)", transition: "transform 0.2s" }}>
              <path d="M6 12l4-4-4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </Link>

        <Link href="/play" className="card group block p-6 no-underline"
          style={{ textDecoration: "none" }}>
          <div className="flex items-center gap-4">
            <div className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(52,211,153,0.08)", border: "1px solid rgba(52,211,153,0.15)", transition: "all 0.2s" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="9" stroke="#34d399" strokeWidth="2"/>
                <path d="M10 8l6 4-6 4V8z" fill="#34d399"/>
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <div style={{ fontWeight: 700, fontSize: "1rem", color: "#ecfdf5", marginBottom: "2px" }}>Join a Game</div>
              <div style={{ fontSize: "0.82rem", color: "rgba(110,231,183,0.55)", fontWeight: 400 }}>Enter room code and compete live</div>
            </div>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, color: "rgba(52,211,153,0.3)", transition: "transform 0.2s" }}>
              <path d="M6 12l4-4-4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </Link>
      </div>

      <p className="anim-fade-up mt-8" style={{ animationDelay: "0.2s", color: "rgba(110,231,183,0.3)", fontSize: "0.75rem", letterSpacing: "0.04em" }}>
        POWERED BY PUSHER
      </p>
    </main>
  );
}
